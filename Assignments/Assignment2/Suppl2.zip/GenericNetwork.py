from AbstractNetwork import AbstractNetwork
from Node import Node

class GenericNetwork(AbstractNetwork):
    def __init__(self, filename):
        """
        Create a network from a file
        """
        